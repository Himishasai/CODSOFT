/* ============================================
   ChalkQuiz — app logic
   All data lives in localStorage. No backend.
   Keys:
     qm_users     -> { username: password }
     qm_session   -> username of logged-in user (or null)
     qm_quizzes   -> [{ id, title, author, questions:[{text, options:[4], correct}] }]
     qm_results   -> [{ id, quizId, quizTitle, user, score, total, date, answers:[{qText, options, correct, picked}] }]
   ============================================ */

const STORAGE = {
  users: 'qm_users',
  session: 'qm_session',
  quizzes: 'qm_quizzes',
  results: 'qm_results',
};

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function writeJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* ---------- App state ---------- */

const state = {
  currentUser: readJSON(STORAGE.session, null),
  takeQuiz: null,        // the quiz currently being taken
  takeIndex: 0,           // current question index
  takeAnswers: [],        // picked option index per question (-1 = unanswered)
};

/* ---------- Navigation ---------- */

const views = ['auth', 'home', 'create', 'browse', 'take', 'results'];

function showView(name) {
  views.forEach(v => {
    document.getElementById('view-' + v).classList.toggle('hidden', v !== name);
  });
  window.scrollTo({ top: 0, behavior: 'auto' });

  if (name === 'home') renderHome();
  if (name === 'create') renderCreateForm();
  if (name === 'browse') renderBrowse();
}

function requireAuthThen(name) {
  if (!state.currentUser && name !== 'auth') {
    showView('auth');
    return;
  }
  showView(name);
}

document.addEventListener('click', (e) => {
  const navTarget = e.target.closest('[data-nav]');
  if (navTarget) {
    requireAuthThen(navTarget.dataset.nav);
  }
});

/* ---------- Auth ---------- */

const topnav = document.getElementById('topnav');
const navUser = document.getElementById('navUser');

function refreshAuthUI() {
  if (state.currentUser) {
    topnav.hidden = false;
    navUser.textContent = '@' + state.currentUser;
  } else {
    topnav.hidden = true;
  }
}

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const isLogin = tab.dataset.tab === 'login';
    document.getElementById('loginForm').classList.toggle('hidden', !isLogin);
    document.getElementById('signupForm').classList.toggle('hidden', isLogin);
  });
});

document.getElementById('loginForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const users = readJSON(STORAGE.users, {});
  const errorEl = document.getElementById('loginError');

  if (!users[username] || users[username] !== password) {
    errorEl.textContent = 'That username and password don\u2019t match.';
    return;
  }
  errorEl.textContent = '';
  logIn(username);
});

document.getElementById('signupForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('signupUsername').value.trim();
  const password = document.getElementById('signupPassword').value;
  const errorEl = document.getElementById('signupError');
  const users = readJSON(STORAGE.users, {});

  if (username.length < 2) {
    errorEl.textContent = 'Username needs at least 2 characters.';
    return;
  }
  if (users[username]) {
    errorEl.textContent = 'That username is taken. Try logging in instead.';
    return;
  }
  errorEl.textContent = '';
  users[username] = password;
  writeJSON(STORAGE.users, users);
  logIn(username);
});

function logIn(username) {
  state.currentUser = username;
  writeJSON(STORAGE.session, username);
  refreshAuthUI();
  document.getElementById('loginForm').reset();
  document.getElementById('signupForm').reset();
  showView('home');
}

document.getElementById('logoutBtn').addEventListener('click', () => {
  state.currentUser = null;
  localStorage.removeItem(STORAGE.session);
  refreshAuthUI();
  showView('auth');
});

/* ---------- Home ---------- */

function renderHome() {
  document.getElementById('homeGreeting').textContent = 'Welcome back, ' + state.currentUser;

  const results = readJSON(STORAGE.results, {})[state.currentUser] || [];
  const strip = document.getElementById('recentResults');
  strip.innerHTML = '';

  if (results.length === 0) {
    strip.innerHTML = '<p class="empty-hint">No quizzes taken yet — go pick one from the shelf.</p>';
    return;
  }

  results.slice(-6).reverse().forEach(r => {
    const chip = document.createElement('div');
    chip.className = 'result-chip';
    chip.innerHTML = `
      <div class="rc-title">${escapeHTML(r.quizTitle)}</div>
      <div class="rc-score">${r.score}/${r.total}</div>
    `;
    strip.appendChild(chip);
  });
}

/* ---------- Create quiz ---------- */

const questionList = document.getElementById('questionList');
let qBlockCount = 0;

function makeQuestionBlock() {
  qBlockCount += 1;
  const blockId = uid();
  const wrap = document.createElement('div');
  wrap.className = 'question-block';
  wrap.dataset.blockId = blockId;
  wrap.innerHTML = `
    <div class="question-block-head">
      <span>Question ${qBlockCount}</span>
      <button type="button" class="remove-q-btn">Remove</button>
    </div>
    <label>Question text
      <input type="text" class="q-text-input" placeholder="e.g. What year did India gain independence?" required>
    </label>
    ${[0, 1, 2, 3].map(i => `
      <div class="option-row">
        <input type="radio" name="correct-${blockId}" value="${i}" ${i === 0 ? 'checked' : ''} required>
        <input type="text" class="q-option-input" placeholder="Option ${i + 1}" required>
      </div>
    `).join('')}
  `;
  wrap.querySelector('.remove-q-btn').addEventListener('click', () => {
    wrap.remove();
    renumberQuestionBlocks();
  });
  return wrap;
}

function renumberQuestionBlocks() {
  const blocks = questionList.querySelectorAll('.question-block');
  qBlockCount = blocks.length;
  blocks.forEach((b, i) => {
    b.querySelector('.question-block-head span').textContent = 'Question ' + (i + 1);
  });
}

document.getElementById('addQuestionBtn').addEventListener('click', () => {
  questionList.appendChild(makeQuestionBlock());
});

function renderCreateForm() {
  document.getElementById('createForm').reset();
  questionList.innerHTML = '';
  qBlockCount = 0;
  document.getElementById('createError').textContent = '';
  questionList.appendChild(makeQuestionBlock());
  questionList.appendChild(makeQuestionBlock());
}

document.getElementById('createForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const title = document.getElementById('quizTitle').value.trim();
  const errorEl = document.getElementById('createError');
  const blocks = [...questionList.querySelectorAll('.question-block')];

  if (blocks.length === 0) {
    errorEl.textContent = 'Add at least one question.';
    return;
  }

  const questions = [];
  for (const block of blocks) {
    const text = block.querySelector('.q-text-input').value.trim();
    const optionInputs = [...block.querySelectorAll('.q-option-input')];
    const options = optionInputs.map(inp => inp.value.trim());
    const checkedRadio = block.querySelector('input[type="radio"]:checked');

    if (!text || options.some(o => !o) || !checkedRadio) {
      errorEl.textContent = 'Fill in every question, all four options, and mark a correct answer.';
      return;
    }
    questions.push({ text, options, correct: Number(checkedRadio.value) });
  }

  const quizzes = readJSON(STORAGE.quizzes, []);
  quizzes.push({
    id: uid(),
    title,
    author: state.currentUser,
    questions,
    createdAt: Date.now(),
  });
  writeJSON(STORAGE.quizzes, quizzes);
  errorEl.textContent = '';
  showView('browse');
});

/* ---------- Browse ---------- */

const quizGrid = document.getElementById('quizGrid');
const browseEmpty = document.getElementById('browseEmpty');
const browseSearch = document.getElementById('browseSearch');

function renderBrowse() {
  const term = browseSearch.value.trim().toLowerCase();
  const quizzes = readJSON(STORAGE.quizzes, [])
    .slice()
    .reverse()
    .filter(q => !term || q.title.toLowerCase().includes(term) || q.author.toLowerCase().includes(term));

  quizGrid.innerHTML = '';
  browseEmpty.classList.toggle('hidden', quizzes.length > 0);

  quizzes.forEach(q => {
    const card = document.createElement('div');
    card.className = 'quiz-card';
    const mine = q.author === state.currentUser;
    card.innerHTML = `
      <h3>${escapeHTML(q.title)}</h3>
      <p class="quiz-meta">${q.questions.length} question${q.questions.length === 1 ? '' : 's'} · by ${escapeHTML(q.author)}${mine ? ' (you)' : ''}</p>
      <div class="quiz-card-actions">
        <button class="btn btn-primary" data-take="${q.id}">Take quiz</button>
        ${mine ? `<button class="btn btn-ghost" data-delete="${q.id}">Delete</button>` : ''}
      </div>
    `;
    quizGrid.appendChild(card);
  });
}

browseSearch.addEventListener('input', renderBrowse);

quizGrid.addEventListener('click', (e) => {
  const takeBtn = e.target.closest('[data-take]');
  const delBtn = e.target.closest('[data-delete]');

  if (takeBtn) {
    startQuiz(takeBtn.dataset.take);
  }
  if (delBtn) {
    const quizzes = readJSON(STORAGE.quizzes, []).filter(q => q.id !== delBtn.dataset.delete);
    writeJSON(STORAGE.quizzes, quizzes);
    renderBrowse();
  }
});

/* ---------- Take quiz ---------- */

function startQuiz(quizId) {
  const quiz = readJSON(STORAGE.quizzes, []).find(q => q.id === quizId);
  if (!quiz) return;
  state.takeQuiz = quiz;
  state.takeIndex = 0;
  state.takeAnswers = quiz.questions.map(() => -1);
  document.getElementById('takeQuizTitle').textContent = quiz.title;
  buildProgressDots();
  showView('take');
  renderQuestion();
}

function buildProgressDots() {
  const dots = document.getElementById('progressDots');
  dots.innerHTML = '';
  state.takeQuiz.questions.forEach(() => {
    const d = document.createElement('span');
    d.className = 'p-dot';
    dots.appendChild(d);
  });
}

function updateProgressDots() {
  const dots = document.getElementById('progressDots').children;
  [...dots].forEach((d, i) => {
    d.classList.toggle('done', state.takeAnswers[i] !== -1 && i !== state.takeIndex);
    d.classList.toggle('current', i === state.takeIndex);
  });
}

function renderQuestion() {
  const quiz = state.takeQuiz;
  const i = state.takeIndex;
  const q = quiz.questions[i];

  document.getElementById('qCount').textContent = `Question ${i + 1} of ${quiz.questions.length}`;
  document.getElementById('qText').textContent = q.text;

  const optionsList = document.getElementById('optionsList');
  optionsList.innerHTML = '';
  q.options.forEach((opt, idx) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'option-btn' + (state.takeAnswers[i] === idx ? ' selected' : '');
    btn.innerHTML = `<span class="option-bubble"></span><span>${escapeHTML(opt)}</span>`;
    btn.addEventListener('click', () => {
      state.takeAnswers[i] = idx;
      renderQuestion();
    });
    optionsList.appendChild(btn);
  });

  document.getElementById('prevQBtn').disabled = i === 0;
  document.getElementById('prevQBtn').style.visibility = i === 0 ? 'hidden' : 'visible';

  const isLast = i === quiz.questions.length - 1;
  document.getElementById('nextQBtn').classList.toggle('hidden', isLast);
  document.getElementById('submitQuizBtn').classList.toggle('hidden', !isLast);

  updateProgressDots();
}

document.getElementById('prevQBtn').addEventListener('click', () => {
  if (state.takeIndex > 0) {
    state.takeIndex -= 1;
    renderQuestion();
  }
});

document.getElementById('nextQBtn').addEventListener('click', () => {
  if (state.takeAnswers[state.takeIndex] === -1) {
    return; // must pick an answer first
  }
  if (state.takeIndex < state.takeQuiz.questions.length - 1) {
    state.takeIndex += 1;
    renderQuestion();
  }
});

document.getElementById('submitQuizBtn').addEventListener('click', () => {
  if (state.takeAnswers[state.takeIndex] === -1) {
    return;
  }
  finishQuiz();
});

/* ---------- Results ---------- */

function finishQuiz() {
  const quiz = state.takeQuiz;
  let score = 0;
  const answers = quiz.questions.map((q, i) => {
    const picked = state.takeAnswers[i];
    const isCorrect = picked === q.correct;
    if (isCorrect) score += 1;
    return {
      qText: q.text,
      options: q.options,
      correct: q.correct,
      picked,
    };
  });

  const allResults = readJSON(STORAGE.results, {});
  const userResults = allResults[state.currentUser] || [];
  userResults.push({
    id: uid(),
    quizId: quiz.id,
    quizTitle: quiz.title,
    score,
    total: quiz.questions.length,
    date: Date.now(),
    answers,
  });
  allResults[state.currentUser] = userResults;
  writeJSON(STORAGE.results, allResults);

  renderResults(quiz.title, score, quiz.questions.length, answers);
  showView('results');
}

function renderResults(title, score, total, answers) {
  document.getElementById('resultsQuizTitle').textContent = title;
  document.getElementById('scoreLine').textContent = `You scored ${score} out of ${total}.`;

  const pct = total === 0 ? 0 : Math.round((score / total) * 100);
  const stamp = document.getElementById('scoreStamp');
  stamp.classList.toggle('pass', pct >= 60);
  document.getElementById('scorePercent').textContent = pct + '%';

  const reviewList = document.getElementById('reviewList');
  reviewList.innerHTML = '';
  answers.forEach((a, i) => {
    const isCorrect = a.picked === a.correct;
    const item = document.createElement('div');
    item.className = 'review-item ' + (isCorrect ? 'correct' : 'incorrect');
    const pickedText = a.picked === -1 ? 'No answer' : a.options[a.picked];
    item.innerHTML = `
      <div class="review-q">${i + 1}. ${escapeHTML(a.qText)}</div>
      <div class="review-line">Your answer: <span class="${isCorrect ? 'tag-correct' : 'tag-incorrect'}">${escapeHTML(pickedText)}</span></div>
      ${!isCorrect ? `<div class="review-line">Correct answer: <span class="tag-correct">${escapeHTML(a.options[a.correct])}</span></div>` : ''}
    `;
    reviewList.appendChild(item);
  });
}

/* ---------- Utility ---------- */

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* ---------- Seed sample quizzes ---------- */

function seedQuizzesIfEmpty() {
  const existing = readJSON(STORAGE.quizzes, []);
  if (existing.length > 0) return;

  const seeded = [
    {
      id: uid(),
      title: 'Web Development Basics',
      author: 'ChalkQuiz Team',
      createdAt: Date.now(),
      questions: [
        {
          text: 'What does HTML stand for?',
          options: ['HyperText Markup Language', 'Home Tool Markup Language', 'Hyperlinks and Text Markup Language', 'HighText Machine Language'],
          correct: 0,
        },
        {
          text: 'Which CSS property controls the size of text?',
          options: ['font-size', 'text-style', 'font-weight', 'text-size'],
          correct: 0,
        },
        {
          text: 'Which HTML tag links an external CSS file to a page?',
          options: ['<style>', '<link>', '<script>', '<css>'],
          correct: 1,
        },
        {
          text: 'In JavaScript, which keyword declares a variable that can be reassigned later?',
          options: ['const', 'let', 'final', 'static'],
          correct: 1,
        },
        {
          text: 'What does CSS stand for?',
          options: ['Cascading Style Sheets', 'Creative Style System', 'Computer Styled Sheets', 'Colorful Style Syntax'],
          correct: 0,
        },
      ],
    },
    {
      id: uid(),
      title: 'World Geography Quickfire',
      author: 'ChalkQuiz Team',
      createdAt: Date.now(),
      questions: [
        {
          text: 'Which is the largest continent by area?',
          options: ['Africa', 'Asia', 'Europe', 'North America'],
          correct: 1,
        },
        {
          text: 'The Himalayas mountain range is home to which peak, the tallest above sea level?',
          options: ['K2', 'Kangchenjunga', 'Mount Everest', 'Nanga Parbat'],
          correct: 2,
        },
        {
          text: 'Which river is traditionally cited as the longest in the world?',
          options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'],
          correct: 1,
        },
        {
          text: 'Which is the smallest country in the world by area?',
          options: ['Monaco', 'Vatican City', 'San Marino', 'Liechtenstein'],
          correct: 1,
        },
        {
          text: 'Which country has the largest population as of the mid-2020s?',
          options: ['China', 'India', 'United States', 'Indonesia'],
          correct: 1,
        },
      ],
    },
  ];

  writeJSON(STORAGE.quizzes, seeded);
}

/* ---------- Boot ---------- */

seedQuizzesIfEmpty();
refreshAuthUI();
if (state.currentUser) {
  showView('home');
} else {
  showView('auth');
}
