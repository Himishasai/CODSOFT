# ChalkQuiz — Online Quiz Maker

CodSoft Web Development Internship — **Level 2, Task 2**

A quiz platform where users can sign up, write their own multiple-choice
quizzes, browse quizzes other people made, take them one question at a
time, and see a scored review at the end.

## Features (mapped to the task brief)

- **Home Page** — welcome message, quick links to create or take a quiz, a strip of your recent scores.
- **Quiz Creation** — add a title, add as many questions as you like, each with 4 options and a marked correct answer.
- **Quiz Taking** — one question per screen, progress dots, back/next navigation, can't advance without answering.
- **Quiz Results** — percentage "stamp," score line, and a full review showing your answer vs. the correct one for every question.
- **Quiz Listing** — searchable grid of all published quizzes, with a delete option for quizzes you created.
- **User Authentication** — sign up / log in, session persists across page reloads.
- **Mobile Responsive** — single-column layouts and adjusted type scale under 640px.

## Sample content

Two quizzes ("Web Development Basics" and "World Geography Quickfire",
5 questions each) are seeded automatically the first time the app runs
with no data in storage — so the Browse page has something to click on
for your demo video without any manual setup. Delete them once you've
recorded, or leave them as filler; either is fine.

## Tech

Plain HTML, CSS, and JavaScript — no build step, no framework, no backend.
Data (accounts, quizzes, results) is stored in the browser's `localStorage`.
That keeps it deployable on any static host in one click, which is the
right trade-off for this task since it doesn't call for a specific stack.

**Note on auth:** this is a client-side demo account system for a static
site — good for showing the feature and grading yourself locally, but
passwords aren't hashed or sent anywhere. Don't reuse a real password here.

## Running it locally

No install needed. Just open `index.html` in a browser, or serve the
folder with any static server, e.g.:

```bash
npx serve .
# or
python3 -m http.server 8000
```

## Deploying (for your submission video/link)

Any static host works since it's just three files:

- **GitHub Pages**: push this folder to a repo, then Settings → Pages →
  deploy from the `main` branch.
- **Netlify**: drag the `quiz-maker` folder onto https://app.netlify.com/drop.

## Submitting to CodSoft

1. Push this folder into your `CODSOFT` GitHub repo (e.g. as a
   `web-development-quiz-maker` subfolder).
2. Deploy it (GitHub Pages or Netlify both work) and grab the live link.
3. Record a short screen-capture demoing: sign up, create a quiz, browse,
   take it, and view the results screen.
4. Post the video on LinkedIn, tag CodSoft, and add `#codsoft
   #internship #webdevelopment`.
5. Fill out the task submission form with your GitHub repo link and the
   live demo link once CodSoft emails it to you.
